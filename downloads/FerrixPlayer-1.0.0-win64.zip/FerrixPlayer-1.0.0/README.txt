Ferrix Player 1.0.0 (Windows x64)

Requirements
- Windows 10 or 11, 64-bit
- VLC 3.x, 64-bit (https://www.videolan.org/vlc/)

Run
- Keep FerrixPlayer.exe, app.ico and help.png in the same folder.
- Double-click FerrixPlayer.exe.
- Windows SmartScreen may warn because the app is unsigned: More info -> Run anyway.
- Add a playlist (M3U) or Xtream account in Sources, then enter your
  XMLTV guide URL with Sources -> XMLTV guide.

Shortcuts
- Arrows / Enter: browse and play
- F: favourite  G: guide  S: sources
- M: preview mute/unmute  F1: help  Esc: back
- In the player: Space pause, Up/Down volume, F11 fullscreen, Esc back

Ferrix Player does not include or host any channels or guide data.
Only use services you are authorised to access.
